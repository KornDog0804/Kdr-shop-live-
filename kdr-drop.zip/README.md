# Korndog Records – Drop-in site

This bundle gives you:

- `/` (index) – reads **/content/live.json**
- `/admin` – edit + publish JSON to your bucket
- `netlify/functions/publish` – writes `content/live.json` to your UpCloud S3 bucket
- `netlify.toml` – routes + proxy so `/content/*` is fetched from your bucket

## Deploy steps

1. Drag this whole folder into a new GitHub repo and connect it to Netlify (or drag-and-drop the folder on app.netlify.com to deploy).
2. In Netlify **Site → Settings → Environment**, add these variables:

```
S3_ENDPOINT = https://jii3i.upcloudobjects.com
S3_REGION   = us-1
S3_BUCKET   = korndog-media
S3_FORCE_PATH_STYLE = true

# Use either pair you already have
S3_KEY      = <your-access-key-id>
S3_SECRET   = <your-secret-access-key>
# (or S3_ACCESS_KEY_ID / S3_SECRET_ACCESS_KEY)
```

3. In your bucket, create folder **content/** and add an initial file **live.json** (you can also press *Load* in /admin to see if it exists).
4. Visit `/admin`, paste/edit JSON, press **Save**. The homepage will load from `/content/live.json`.

> If your bucket path is different, edit `netlify.toml` redirect that targets the UpCloud bucket URL.
