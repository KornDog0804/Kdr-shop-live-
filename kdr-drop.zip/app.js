// app.js
const invEl = document.getElementById('inventory');
const heroImg = document.getElementById('hero-img');
const headline = document.getElementById('headline');

async function load() {
  try {
    // Served via Netlify proxy to UpCloud (see netlify.toml)
    const r = await fetch('/content/live.json?_=' + Date.now());
    if (!r.ok) throw new Error('Failed to load content JSON');
    const data = await r.json();

    // Hero
    headline.textContent = (data.hero && data.hero.headline) || 'Korndog Records';
    heroImg.src = (data.hero && data.hero.img) || 'https://placehold.co/1200x480/111/fff?text=Korndog+Records';

    // Inventory (records + funkos)
    const items = [
      ...(Array.isArray(data.records) ? data.records : []),
      ...(Array.isArray(data.funkos) ? data.funkos : []),
    ];
    if (!items.length) {
      invEl.textContent = 'No items yet.';
      return;
    }

    const grid = document.createElement('div');
    grid.className = 'grid';
    items.forEach(i => {
      const card = document.createElement('div');
      card.className = 'card';
      const img = document.createElement('img');
      img.src = i.img || 'https://placehold.co/400x400';
      img.alt = i.title || i.name || 'item';
      const title = document.createElement('div');
      title.textContent = i.title || i.name || 'Untitled';
      const price = document.createElement('div');
      price.className = 'small';
      price.textContent = i.price ? `$${i.price}` : '';
      card.append(img, title, price);
      grid.append(card);
    });
    invEl.innerHTML = '';
    invEl.append(grid);
  } catch (e) {
    console.error(e);
    invEl.textContent = 'Failed to load content.';
  }
}
load();
